import numpy as np
import joblib
import re
import string

class MisinfoModel:
    def __init__(self):
        self.model = None
        self.vectorizer = None
        self.POS_TAGS = ['$', "''", '(', ')', ',', '--', '.', ':', 'CC', 'CD', 'DT', 'EX', 'FW', 'IN', 'JJ', 'JJR', 'JJS', 'LS', 'MD', 'NN', 'NNP', 'NNPS', 'NNS', 'PDT', 'POS', 'PRP', 'PRP$', 'RB', 'RBR', 'RBS', 'RP', 'SYM', 'TO', 'UH', 'VB', 'VBD', 'VBG', 'VBN', 'VBP', 'VBZ', 'WDT', 'WP', 'WP$', 'WRB', '``']
        self.load_model()

    def load_model(self):
        try:
            self.lr = joblib.load("app/models/logistic_regression_model.pkl")
            self.le = joblib.load("app/models/label_encoder.pkl")
            print("Models loaded successfully.")
        except Exception as e:
            print(f"Error loading models: {e}")
            self.lr = None
            self.le = None

    def is_loaded(self):
        return self.lr is not None and self.le is not None
    
    def predict(self, input_text: str):
        if not self.is_loaded():
            raise Exception("Model is not being loaded")
            
        try:
            pos_tags = self.extract_pos_tags(input_text)
        
            # Make prediction
            prediction = self.lr.predict([pos_tags])[0]
            confidence = np.max(self.lr.predict_proba([pos_tags])[0])

            prediction_label = self.le.inverse_transform([prediction])[0]
        
            return prediction_label, float(confidence)
    
        except Exception as e:
            print(f"DEBUG MODEL ERROR: {e}")
            raise
    
    def extract_pos_tags(self, text: str):
        import spacy

        nlp = spacy.load("en_core_web_sm")
    
        clean_text = self.clean_text(text)
        doc = nlp(clean_text)
    
        pos_counts = {tag: 0 for tag in self.POS_TAGS}
        for token in doc:
            if token.pos_ in pos_counts:
                pos_counts[token.pos_] += 1
    
        return [pos_counts[tag] for tag in self.POS_TAGS]
    
    def clean_text(self, text: str):
        if not text:
            return ''
        text = text.lower()
        text = re.sub(r"http\S+|www\S+|https\S+", '', text)
        text = re.sub(r'\@\w+|\#','', text)
        text = text.translate(str.maketrans('', '', string.punctuation))
        text = re.sub(r'\d+', '', text)
        text = text.strip()
        return text

