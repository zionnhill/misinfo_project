from fastapi import FastAPI,HTTPException
from fastapi.middleware.cors import CORSMiddleware
from app.model import MisinfoModel
from pydantic import BaseModel, Field
from app.utils import logger

app = FastAPI(
    title="Backend Misinfo Project API",
    description="Application Programming Interface for the Backend Misinfo Project",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"], # URL of React application
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

model = MisinfoModel()
print(f"DEBUG: Model loaded status: {model.is_loaded()}")  # Add this line

class PredictionInput(BaseModel):
    # Field defines constraints for input validation
    input_text: str = Field(..., min_length=1, max_length=5000, description="Input text that is analysed for misinformation detection")  # Must be greater than 0

class PredictionOutput(BaseModel):
    prediction: str
    confidence: float
    is_misinfo: bool

@app.get("/")
async def root():
    return {"message": "Welcome to the Misinformation Detection API"}

@app.post("/predict", response_model=PredictionOutput)
async def predict(input: PredictionInput):
    try:
        if not model.is_loaded():
            raise HTTPException(status_code=503, detail="Model is not loaded. Please try again later.")

        prediction, confidence = model.predict(input.input_text)
        
        logger.info(f"Prediction made: {prediction} with confidence {confidence}")

        return PredictionOutput(
            prediction=prediction,
            confidence=confidence,
            is_misinfo=prediction in ["false", "pants-fire", "barely-true"]
        )

    except Exception as e:
        logger.error(f"Error during prediction: {str(e)}")
        print(f"DEBUG FULL ERROR: {e}")  # Add this
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")
    
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)






